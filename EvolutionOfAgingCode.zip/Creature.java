/**

This code was used in the study titled: "Effects of Extrinsic Mortality on the Evolution of Aging: A Stochastic Modeling Approach." 

Copyright (c) 2013, Maxim N. Shokhirev
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 */


public class Creature {

	int age = 0;  // age of creature 
	double energy =1;
	double maturation_energy = 0;
	double metabolic_cost = 0;
	double TdieUpkeepEnergy = 0;
	double total_current_maintenance = 0;
	double reproduction_energyUsed= 0;
	/* Females only */
	boolean female; 
	Creature father; 
	double f; //fraction on top of metabolism required to achieve sufficient growth to be grown up assuming Tmat, Ezero, and Emat
	double m; // multiplier used to compute the current size
	double current_m = 1.0; // used to keep track of the cumulative multiplier as the creature ages
	double fractional_size = 0;
	double TdieUpkeep = 0;
	/*  EVOLVABLE QUANTITIES */
	double[] properties = new double[2]; 
	Simulation s;
	//Tmaturation, Tdie
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public int deathEffects(Ticker t)
	{
		/**********************************************
		 *  METABOLISM
		 *********************************************/
		double available=t.getEnergyAvailableGreedy();
		//assume you can take up to the available 
		double eating_capacity = fractional_size*s.adultMetabolicCost*5*(1.1-0.2*Math.random());

	//	foraged -= foraged*Math.random()*0.1;
		//metabolism depends on your properties:
		
		TdieUpkeepEnergy = fractional_size*TdieUpkeep;
		maturation_energy = 0;
		metabolic_cost = s.adultMetabolicCost;
		if(age < properties[0])
		{
			metabolic_cost =  fractional_size*s.adultMetabolicCost;
			maturation_energy = metabolic_cost*f;
		}
		total_current_maintenance = TdieUpkeepEnergy+maturation_energy+metabolic_cost;
		double foraged = Math.max(0,Math.min(available, Math.min(eating_capacity,fractional_size*s.adultMetabolicCost*25-energy+total_current_maintenance)));
		energy+=foraged-total_current_maintenance;
		t.Energy-=foraged;
		/**********************************************
		 *  DEATH EFFECTS ARE CHECKED 1= starved, 2= aged, 3=eaten
		 *********************************************/
		boolean died_from_old_age = (age >= properties[1]);
		if(energy <= 0) return 1;
		else if(died_from_old_age) return 2;
		else if(Math.random() < t.predationProbability) return 3;
		/**********************************************
		 *  AGING
		 *********************************************/
		age++;
		if(age <properties[0])
		{
			current_m*=m;
			fractional_size = (s.Ezero*current_m)/s.Emat;
		}
		else
		{
			reproduction_energyUsed= 0;
			fractional_size = 1.0;
		}
		return 0;  //still living
	}
	
	public Creature(double[] properties, boolean female, Simulation s)
	{
		this.properties = properties;
		this.female = female;
		this.s = s;
		initialize();
	}
	
	public Creature(Creature mom, Creature dad, Simulation s) {
		this.s = s;
		for(int i = 0; i < properties.length; i++)
		{
			double min = Math.min(mom.properties[i],dad.properties[i]);
			double max = Math.max(mom.properties[i],dad.properties[i]);
			properties[i] = (Math.random()*(max-min)+min)*((1.0-0.5*s.evolvability[i])+Math.random()*s.evolvability[i]);
		}
		if(Math.random() <= 0.5) female = true;
		initialize();	
	}
	
	private void initialize()
	{
		energy = s.Ezero;
		fractional_size=s.Ezero/s.Emat;
		m = Math.exp(Math.log(s.Emat/s.Ezero)/properties[0]);
		f = (m-1)/(s.adultMetabolicCost*s.growthEfficiency);
		current_m = 1.0;
		double repairFraction = 1;
		if(s.deathType != s.SigmoidLOW && s.deathType != s.SigmoidHIGH)
		{
			 repairFraction= 1.0*Math.exp(Math.log(0.1)/properties[1]);
		}
		/*
		 * 0= Sigmoid low, 1= Linear low, 2= Asymptotic Low, 3= Sigmoid high, 4= linear high, 5= Asymptotic High
		 */
		 switch(s.deathType)
		 {
		 	case 0: TdieUpkeep = 2*Math.exp(-7*Math.exp(-0.0132*properties[1]));break;
		 	case 1: TdieUpkeep = 0.005/(1.0-repairFraction); break;
		 	case 2: TdieUpkeep = 0.02/(1.02-repairFraction); break;
		 	case 3: TdieUpkeep = 1.5*Math.exp(-7*Math.exp(-0.03*properties[1]));break;
		 	case 4: TdieUpkeep = 0.01/(1.0-repairFraction); break;     //
		 	case 5: TdieUpkeep = 0.035/(1.03-repairFraction); break;
		 	
		 	
		 }
	}

	public void mate(Creature father)
	{
		this.father = father;
	}
	
	public Creature[] getOffSpring()
	{
		int num_offspring = getNumOffspring();
		Creature[] offspring = new Creature[num_offspring];
		for(int i = 0; i < num_offspring; i++)
		{
			offspring[i] = new Creature(this,father,s);
		}
		return offspring;
	}


	public int getNumOffspring() {
		// TODO Auto-generated method stub
		return (int)Math.round((Math.random()*s.num_offspring_range+s.num_offspring_min));  //comment this line for the increased fertility test
		//return (int)Math.round(1+8*Math.max(0,(age-properties[0])/(properties[1]-properties[0])) ); uncomment this line for the increased fertility test
	}
	
	public double mattingSuccessChance()
	{
		return (1.0-(age-properties[0])/(properties[1]-properties[0]));   //comment this line for the increased fertility test.
//		return 0.5;  uncomment this line for the increased fertility test.
	}



}
