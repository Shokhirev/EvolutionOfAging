
public class Parameters {

	
	Optimization saa = null;
	volatile double food,growthEfficiency,Ezero,Emate,Ethreshold;
	volatile int deathType;
	
	public Parameters(Optimization saa)
	{
		this.saa = saa;
		initializeParameters();
	}
	
	public Parameters(Parameters p, double delta)
	{
		this.saa = p.saa;
		boolean bad = true;
		while(bad)
		{
			food = p.food*(1.0-delta/2+Math.random()*delta*p.food);
			if(food < saa.foodRange[0]) food= saa.foodRange[0]+(saa.foodRange[0]-food);
			if(food > saa.foodRange[1]) food= saa.foodRange[1]-(food-saa.foodRange[1]);
			growthEfficiency = p.growthEfficiency*(1.0-delta/2+Math.random()*delta*p.growthEfficiency);
			if(growthEfficiency < saa.growthEfficiencyRange[0]) growthEfficiency= saa.growthEfficiencyRange[0]+(saa.growthEfficiencyRange[0]-growthEfficiency);
			if(growthEfficiency > saa.growthEfficiencyRange[1]) growthEfficiency= saa.growthEfficiencyRange[1]-(growthEfficiency-saa.growthEfficiencyRange[1]);
			Ezero = p.Ezero*(1.0-delta/2+Math.random()*delta*p.Ezero);
			if(Ezero < saa.EzeroRange[0]) Ezero= saa.EzeroRange[0]+(saa.EzeroRange[0]-Ezero);
			if(Ezero > saa.EzeroRange[1]) Ezero= saa.EzeroRange[1]-(Ezero-saa.EzeroRange[1]);
			Emate = p.Emate*(1.0-delta/2+Math.random()*delta*p.Emate);
			if(Emate < saa.EmateMultiplierRange[0]) Emate= saa.EmateMultiplierRange[0]+(saa.EmateMultiplierRange[0]-Emate);
			if(Emate > saa.EmateMultiplierRange[1]) Emate= saa.EmateMultiplierRange[1]-(Emate-saa.EmateMultiplierRange[1]);
			Ethreshold = p.Ethreshold*(1.0-delta/2+Math.random()*delta*p.Ethreshold);
			if(Ethreshold < saa.EthresholdMultiplierRange[0]) Ethreshold= saa.EthresholdMultiplierRange[0]+(saa.EthresholdMultiplierRange[0]-Ethreshold);
			if(Ethreshold > saa.EthresholdMultiplierRange[1]) Ethreshold= saa.EthresholdMultiplierRange[1]-(Ethreshold-saa.EthresholdMultiplierRange[1]);
			double val = Math.random();
			if(delta > 0)
			{
				if(val < 1.0/3.0)
					deathType = Math.abs((p.deathType-1));
				else if(val > 2.0/3.0)
				{
					deathType = (p.deathType+1);
					if(deathType == saa.deathTypes.length)
						deathType =saa.deathTypes.length-2;
				}
				else
					deathType = p.deathType;
			}
			else
				deathType = p.deathType;
			if(food > saa.foodRange[0] && growthEfficiency > saa.growthEfficiencyRange[0] && Ezero > saa.EzeroRange[0] && Emate > saa.EmateMultiplierRange[0] && Ethreshold > saa.EthresholdMultiplierRange[0]&&
					food < saa.foodRange[1] && growthEfficiency < saa.growthEfficiencyRange[1] && Ezero < saa.EzeroRange[1] && Emate < saa.EmateMultiplierRange[1] && Ethreshold < saa.EthresholdMultiplierRange[1])
			{
				bad = false;
			}
			else
			{
				System.err.println("ERROR PARAMETER(S) WERE NEGATIVE! : "+toString());
			}
		}
	}
	
	public Parameters(Optimization simulatedAnealingAging, double food,
			double growthEfficiency, double Ezero, double Emate, double Ethreshold, int deathType) {
			this.saa = simulatedAnealingAging;
			this.food = food;
			this.growthEfficiency = growthEfficiency;
			this.Ezero=Ezero;
			this.Emate =Emate;
			this.Ethreshold = Ethreshold;
			this.deathType=deathType;
	}

	private void initializeParameters()
	{
		food = Math.random()*(saa.foodRange[1]-saa.foodRange[0])+saa.foodRange[0];
		growthEfficiency = Math.random()*(saa.growthEfficiencyRange[1]-saa.growthEfficiencyRange[0])+saa.growthEfficiencyRange[0];
		Ezero = Math.random()*(saa.EzeroRange[1]-saa.EzeroRange[0])+saa.EzeroRange[0];
		Emate = Math.random()*(saa.EmateMultiplierRange[1]-saa.EmateMultiplierRange[0])+saa.EmateMultiplierRange[0];
		Ethreshold = Math.random()*(saa.EthresholdMultiplierRange[1]-saa.EthresholdMultiplierRange[0])+saa.EthresholdMultiplierRange[0];
		deathType = saa.deathTypes[(int)(saa.deathTypes.length*Math.random())];
	}
	
	public String toString()
	{
		return String.format("FoodM=,%f,growthEf=,%f,EzeroM=,%f,EmateM=,%f,EthresholdM=,%f,deathType=,%d",food,growthEfficiency, Ezero,Emate,Ethreshold,deathType);
	}
	
	public Parameters getNeighbor(double delta)
	{
		return new Parameters(this,delta);
	}
	
	
	
	
}
