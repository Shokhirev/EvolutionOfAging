import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;



public class SimulatedAnealingAging extends Optimization {

	
	
	public SimulatedAnealingAging( boolean lookForRise)
	{
		//lets generate the initial set of simulations
		String startDate =Simulation.now();
		System.err.println("Look for rise? "+lookForRise+" Started on: "+startDate);
		Parameters current = new Parameters(this);
		Parameters best = new Parameters(this);
		double best_score = -9999999;
		double current_score = -999999;
		double Tstart = 100;
		double Tend = 0.5;  //~103 trials
		double Tmultiplier = 0.95;
		double T = Tstart;
		while(T > Tend)
		{
			Parameters neighbor = current.getNeighbor(0.1);  //5% change
			if(Math.random() > 0.9)
				neighbor = current.getNeighbor(0.5);  //25% change
			//evaluate the simulation
			//***************Simulation predations to run and their corresponding thread-counts
			double[] predations = 	{0.0025,0.005,0.01,0.02,0.04};
			int[] threads = 		{    4,    2,  2,   1,   1};
			Simulation[] simulations = new Simulation[predations.length];
			for(int t =0; t < predations.length; t++)
			{
				if(threads[t]>0)
				{
					simulations[t] = new Simulation(threads[t],predations[t]);
					//now lets set all of the simulation parameters:
					System.err.println("Setting parameters to: "+neighbor.toString()+" pm = "+predations[t]);
					simulations[t].setParameters(neighbor.food, neighbor.Ezero, neighbor.Emate, neighbor.Ethreshold, neighbor.growthEfficiency, neighbor.deathType,false,16,300000);
					simulations[t].start();
				}
			}
			//now lets see what the the Tdie looks like for increasing pms!
			for(Simulation s: simulations)
			{
				try {
					s.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//now that all of the simulations have finished... we can look at the average pms
			double[] Tdies = new double[simulations.length];
			int avg_count =1000;
			int Nans = 0;
			for(int i = 0; i < simulations.length; i++)
			{
				try{
				for(int j = simulations[i].savedStates.length-avg_count; j < simulations[i].savedStates.length; j++)
				{
					Tdies[i]+=simulations[i].savedStates[j][21]/simulations[i].alive[j];
				}
				Tdies[i]/=avg_count;
				}catch(Exception e)
				{
					Tdies[i] = Double.NaN;
				}
				if(Double.isNaN(Tdies[i]))
					Nans++;
				System.err.println("pm="+predations[i]+" -> AvgTdie="+Tdies[i]);
			}
			//ok now lets score this set of simulations based on how well Tdies increased or decreased
			
			double score =-9999;
			boolean NaNFound = false;
	
			if(lookForRise)
			{
				int count = 0;
				double amount = 0;
				double rightamount = 0;
				for(int i = 1;i < Tdies.length; i++)
				{
					double before = Tdies[i-1];
					double now = Tdies[i];
					if(now > before)
					{
						count++;
						rightamount+=(now-before);
					}
					amount+=(now-before);
				}
				if(count <Tdies.length-1)
					score= (count*5*rightamount+amount)/(Tdies[0]);
				else
					score= (100*amount)/(Tdies[0]);
				if(Double.isNaN(score))
				{
					score = -999999;
			//		T/=Tmultiplier;
					NaNFound=true;
				}
			}
			else
			{
				int count = 0;
				double amount = 0;
				double rightamount = 0;
				for(int i = 1;i < Tdies.length; i++)
				{
					double before = Tdies[i-1];
					double now = Tdies[i];
					if(now < before)
					{
						count++;
						rightamount+=(before-now);
					}
					amount+=(before-now);
				}
				if(count <Tdies.length-1)
					score= (count*5*rightamount+amount)/(Tdies[Tdies.length-1]);
				else
					score= (100*amount)/(Tdies[Tdies.length-1]);
				if(Double.isNaN(score))
				{
					score = -999999;
				//	T/=Tmultiplier;
					NaNFound=true;
				}
			}
			if(!NaNFound)
			{
				double probability = Math.exp((score-current_score)/T);
				if(Math.random() < probability || T == Tstart)
				{
					//we take it!
					current = neighbor;
					System.err.println("T="+T+" Prev Score = "+current_score+" current score = "+score+" probability="+probability+". KEPT! Params= "+current.toString());
					current_score = score;
					if(score > best_score)
					{
						best_score = score;
						best = new Parameters(current,0);
					}
				}
				else
					System.err.println("T="+T+" Prev Score = "+current_score+" current score = "+score+" probability="+probability+". Discarded. Params= "+current.toString());
				T=T*Tmultiplier;
				try {
					PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(startDate+"_SimAging_"+lookForRise+"_.csv", true)));
					out.print("T=,"+T+",Best =,"+current_score+",TryScore=,"+score+",probability=,"+probability+",Params=,"+current.toString());
					for(int i = 0; i < Tdies.length;i++)
						out.print(","+Tdies[i]);
					out.println();
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				if(Nans < 5)
					System.err.println("NAN FOUND>>>>>>>>>>>>>>>>>>> DISCRARDING ))))))))))))))))  T is: "+T);
				else
				{
					System.err.println("Complete failure... restarting from scratch with random parameters...");
					current = new Parameters(this);
					best = new Parameters(this);
					best_score = -9999999;
					current_score = -999999;
					T=Tstart;
					startDate =Simulation.now();
				}
				
			}
			if(T <=Tend)
			{
				//lets check that the optimization produced a decent result
				if(best_score < 100)
				{
					System.err.println("Simulation finished but the score was low("+best_score+"), suggesting that it did not find a solution. Restarting from scratch at random!");
					current = new Parameters(this);
					best = new Parameters(this);
					best_score = -9999999;
					current_score = -999999;
					T=Tstart;
					startDate =Simulation.now();
					
				}
					
			}
		}
		System.err.println("Best solution found after simulated annealing: "+best.toString());
		double[] predations = 	{0.0025,0.005,0.01,0.02,0.04};
		int[] threads = 		{    4,    2,   2,   1,   1};
		Simulation[] simulations = new Simulation[predations.length];
		for(int t =0; t < predations.length; t++)
		{
			if(threads[t]>0)
			{
				simulations[t] = new Simulation(threads[t],predations[t]);
				//now lets set all of the simulation parameters:
				System.err.println("Setting parameters to: "+best.toString()+" pm = "+predations[t]);
				simulations[t].label = "BestParams-"+lookForRise+"-";
				simulations[t].setParameters(best.food, best.Ezero, best.Emate, best.Ethreshold, best.growthEfficiency, best.deathType,true,400,300000);

				simulations[t].start();
			}
		}
	}
	
	public static void main (String[] args)
	{
		//lets run the simulatios and only keep solutions that increase or deacrease Tdie with increase or decreasing PM.
		if(args.length > 1)
		{
			try {
				System.err.println("Sleeping for "+args[1]+" mins");
				Thread.sleep(60000*Integer.parseInt(args[1]));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(args.length==0)
		{
			System.err.println("Usage: SimulatedAnnealingAging LookForRise? [SleepMins]");
			System.exit(1);
		}
		new SimulatedAnealingAging(Boolean.parseBoolean(args[0]));
	}

	
}
