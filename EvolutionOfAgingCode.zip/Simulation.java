
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;




public class Simulation extends Thread {

	//****************** DEATH TYPE DEFINITIONS ********
	public final int SigmoidLOW = 0;
	public final int LINEARLOW = 1;
	public final int ASSYMPTOTICLOW = 2;
	public final int SigmoidHIGH = 3;
	public final int LINEARHIGH = 4;
	public final int ASSYMPTOTICHIGH = 5;
	public volatile int deathType = 2;
	//****************** MODEL CONSTANTS ***************
	//Increase 2.315629	growthEf=	0.020931	EzeroM=	0.006713	EmateM=	0.395539	EthresholdM=	0.524644	deathType=	4	131.0810468	134.4494531	140.8580167	159.0027416	233.253122
	//**************************************************
	//Decrease Params=	FoodM=	0.7271	growthEf=	0.021496	EzeroM=	0.024568	EmateM=	0.983458	EthresholdM=	4.972823	deathType=	4
	//*************************************************
	public int num_offspring_min = 1;
	public int num_offspring_range = 2;
	public volatile double[] evolvability = {0.2,0.2}; //fraction of the average to change 
	public volatile double adultMetabolicCost = 1;
	public volatile double growthEfficiency = 0.022208;//0.052156;// // creatures convert this fraction of their energy to mass during growth/maturation (the lower the more expensive maturation is)
	public volatile double Ezero =0.007202*adultMetabolicCost;//initial energy of offspring 0.02441*adultMetabolicCost;//
	public volatile double Emat =Ezero*50;//energy of mature creature
	public volatile double energyToMate = adultMetabolicCost*3.355974;//adultMetabolicCost*0.5;  //energy required to mate for males AND females 1.648752*adultMetabolicCost;//
	public volatile double matingThreshold = adultMetabolicCost*4.695585;//adultMetabolicCost*1;  //energy required to mate for males AND females 3.581984*adultMetabolicCost;//
	//*************** PREDATION MODIFIER ************
	public volatile double predationModifier = 0; //don't set this explicitly because it will be overwritten anyway
	public volatile double foodMultiplier =2.924626;//1.510778;//
	//**************** INITIAL PARAMS ***************
	public volatile double[] initParamsMins= {45,65};
	public volatile double[] initParamsRanges= {10.0,10};	
	//************* SIMULATION PARAMETERS ***********
	public volatile double populationSize =50;
	public volatile int simulationDuration = 300000;
	public volatile int skip = 30;
	public volatile int runTimes =400;
	private boolean saveToFile = true;
	private boolean outputToScreen = false;
	//************* SAVED DATA *****************
	public volatile double[][] savedStates = new double[simulationDuration/skip][222];
	public volatile int[] alive = new int[simulationDuration/skip];
	public volatile double[][] lastValues = new double[runTimes][222];
	//*************OUTPUT****************
	public volatile String output;  //dont set this explicitly because it will be overwritten anyway
	public volatile int processors = 0;  //dont set this explicitly because it will be overwritten anyway
	public volatile String label = "incFertOldPr1";
	
	public void setParameters(double food, double EzeroM, double EmateM,double EthresholdM, double growE, int dtype, boolean saveToFile, int runTimes, int duration)
	{
		this.foodMultiplier = food;
		this.growthEfficiency = adultMetabolicCost*growE;
		this.Ezero = adultMetabolicCost*EzeroM;
		this.Emat = Ezero*50;
		this.energyToMate = adultMetabolicCost*EmateM;
		this.matingThreshold = adultMetabolicCost*EthresholdM;
		this.deathType = dtype;
		this.runTimes = runTimes;
		this.saveToFile = saveToFile;
		this.simulationDuration = duration;
		this.skip = duration/10000;
		this.savedStates = new double[simulationDuration/skip][222];
		this.alive = new int[simulationDuration/skip];
		this.lastValues = new double[runTimes][222];
		this.output = date()+label+"AgeModel="+deathType+"GroEf="+growthEfficiency+"E0="+Ezero+"Emat="+Emat+"E2mate="+energyToMate+"Ethrsh="+matingThreshold+"Size="+populationSize+"Dur="+simulationDuration+"Times="+runTimes+"Food="+foodMultiplier+"Pm="+predationModifier+".csv";
		System.err.println("PopSize="+populationSize+"\nnumOffspringMin="+num_offspring_min+" numOffspringRange="+num_offspring_range+
				" evolvability= "+evolvability[0]+"|"+evolvability[1]+" Ezero="+Ezero+" Emat="+Emat+" energyToMate="+energyToMate+"\nmateEThreshold="+matingThreshold+" pm="+predationModifier+" FoodMultiplier="+foodMultiplier+" GrowthEfficiency="+growthEfficiency);
	}
	
	public static void main(String[] args)
	{
		//********** WAIT TIME IN MINUTES ***************
		int wait = 0;
		//***********************************************
		if(args.length > 0)
			wait = Integer.parseInt(args[0]);
		
		if(wait > 0)
		{
			System.err.println("Waiting "+ wait+" minutes");
			try {
				Thread.sleep(wait*60000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//***************Simulation predations to run and their corresponding thread-counts
		double[] predations = 	{0.0025,0.005,0.01,0.02,0.04};
		int[] threads = 		{    4,    3,   2,  2,  1 };
		for(int t =0; t < predations.length; t++)
		{
			if(threads[t]>0)
			{
				Simulation s = new Simulation(threads[t],predations[t]);
				s.start();
			}
		}
	}
	
	PrintWriter pw = null;
	public Simulation(int processors, double predation_mod)
	{
		predationModifier = predation_mod;
		this.processors= processors;
	}
	
	public void run()
	{
		int total_runs = 0;
		while(total_runs < runTimes)
		{
			Ticker[] tickers = new Ticker[Math.min(processors,(runTimes-total_runs))];
			for(int i = 0; i < tickers.length; i++)
			{
				tickers[i] = new Ticker(this);
			}
			for(int i = 0; i < tickers.length; i++)
			{
				try{
					tickers[i].join();
				}catch(Exception e){}
			}
			//at this point we have all of the simulation runs finished and we need to compile them together
			for(int i = 0; i < savedStates.length;i++)
			{
				for(int t = 0; t < tickers.length; t++)
				{
					Ticker tick = tickers[t];
					if(tick.savedStates[i][1] > 0)
					{
						for(int j = 0; j < savedStates[i].length; j++)
						{
								savedStates[i][j]+=tick.savedStates[i][j];
						}
						alive[i]++;
						if(i == savedStates.length-1)
						{
							for(int j = 0; j < tick.savedStates[i].length; j++)
							{
									lastValues[total_runs+t][j]=tick.savedStates[i][j];
							}
						}
					}
				}
			}
			total_runs+=tickers.length;
			try{
				System.err.println("("+total_runs+"/"+runTimes+") Creatures: "+lastValues[total_runs-1][1]+" pm = "+predationModifier);
			}catch(Exception e){}
		//System.err.println("("+total_runs+"/"+runTimes+")");

		}
		if(saveToFile)
		{
			this.output = date()+label+"AgeModel="+deathType+"GroEf="+growthEfficiency+"E0="+Ezero+"Emat="+Emat+"E2mate="+energyToMate+"Ethrsh="+matingThreshold+"Size="+populationSize+"Dur="+simulationDuration+"Times="+runTimes+"Food="+foodMultiplier+"Pm="+predationModifier;
			this.output = this.output.replace('.', ',')+".csv";
			System.err.println("PopSize="+populationSize+"\nnumOffspringMin="+num_offspring_min+" numOffspringRange="+num_offspring_range+
					" evolvability="+evolvability[0]+"-"+evolvability[1]+" Ezero="+Ezero+" Emat="+Emat+" energyToMate="+energyToMate+"\nmateEThreshold="+matingThreshold+" pm="+predationModifier+" FoodMultiplier="+foodMultiplier+" GrowthEfficiency="+growthEfficiency);
			try {
				pw = new PrintWriter(new File(output));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			outputHeader();
			outputStates();
			pw.close();
			System.err.println("Saved averages to: "+output);
			try {
				pw = new PrintWriter(new File("Values_"+output));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			outputHeader();
			outputEndValues();
			pw.close();
			System.err.println("Saved Values to: "+"Values_"+output);
		}
		else if (outputToScreen)
		{
			for(int i = 0; i < savedStates.length; i++)
			{
				double[] state = savedStates[i];
				String s = "\t"+(i*skip);
				if(alive[i] > 0)
				{
					for(int j = 0; j< state.length; j++)
						s+=String.format("\t%3.3f",(state[j]/alive[i]));
				}
				s+="\t"+alive[i];
				System.err.println(s);
			}
		}
	}
	
	private void outputEndValues() {
		for(int i = 0; i < lastValues.length; i++)
		{
			String s = ""+lastValues[i][0];
			if(lastValues[i][1] > 0)
			{
				for(int j = 0; j < lastValues[i].length; j++)
					s+=","+lastValues[i][j];
				pw.println(s);
			}
		}
	}

	private void outputHeader() {
		String out = String.format("Simulation carried out on "+now()+" PopSize=%3.3f numOffspringMin=%d numOffspringRange=%d evolvability=%3.3f|%3.3f Ezero=%3.3f Emat=%3.3f energyToMate=%3.3f mateEThreshold=%3.3f pm=%3.3f FoodMultiplier=%3.3f GrowthEfficiency=%3.3f deathType=%d",populationSize,num_offspring_min,num_offspring_range,evolvability[0],evolvability[1],Ezero,Emat,energyToMate,matingThreshold,predationModifier,foodMultiplier,growthEfficiency,deathType)+","+String.format("Time,NonExtinct,NumCreatures,Males,Females,Juveniles,Mature,#births,#starve,#age,#eaten,Pr(eaten),TotEnergy,AvgAge,AvgMatEnergy,AvgJMatF,AvgJMetF,AvgJTdieF,AvgMatMetE,AvgMatTdieE,AvgMatReprodCost,AvgMatTotUsedE,AvgTmat,AvgTdie");
		for(int b = 22; b < 122; b++)
			out+=",Pr(Tmat "+((b-21))+")";
		for(int b = 122; b < 222; b++)
			out+=",Pr(Tdie "+((b-121)*10)+")";
		pw.println(out);
	}


	
	private void outputStates()
	{
		for(int i = 0; i < savedStates.length; i++)
		{
			double[] state = savedStates[i];
			String s = ","+(i*skip);
			s+=","+alive[i];
			if(alive[i] > 0)
			{
				for(int j = 0; j< state.length; j++)
					s+=String.format(",%3.3f",(state[j]/alive[i]));
			}
			
			pw.println(s);
		}
	}

	public static  String DATE_FORMAT_DATE = "yyyy-MM-dd";

	/**
	 * Returns the current date and time
	 * @return
	 */
	  public static String date() {
		    Calendar cal = Calendar.getInstance();
		    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_DATE);
		    return sdf.format(cal.getTime());
		  }
	public static  String DATE_FORMAT_NOW = "yyyy-MM-dd HH-mm-ss";

	/**
	 * Returns the current date and time
	 * @return
	 */
	  public static String now() {
		    Calendar cal = Calendar.getInstance();
		    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		    return sdf.format(cal.getTime());
		  }

}
