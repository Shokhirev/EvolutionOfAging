
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;


public class Ticker extends Thread{

	LinkedList<Creature> living = new LinkedList<Creature>();
	HashMap<Creature,Boolean> females = new HashMap<Creature,Boolean>();
	HashMap<Creature,Boolean> males = new HashMap<Creature,Boolean>();
	Simulation s;

	double Energy=0;
	double predationProbability = 0;
	double totalSize = 0;
	double[][] savedStates= null;
	
	public Ticker(Simulation simulation)
	{
		s=simulation;
		Energy =s.populationSize*s.adultMetabolicCost*3;
		savedStates = new double[s.simulationDuration/s.skip][222];
		predationProbability = s.predationModifier;
		start();
	}
	@Override
	public void run()
	{
		initializeSimulation();
		//System.err.print('!');
		for(int t= 0; t < s.simulationDuration;t++)
		{
			if(living.size() > 0)
			{
				int info[] =tick();
				if(t%s.skip==0)saveSimulationState(t,info);
			}
			else
			{
				System.err.println("Simulation for pm="+s.predationModifier+" went extinct at t= "+t);
				break;
			}
		}
		living.clear();
		females.clear();
		males.clear();
		
	//	System.err.print('.');
	}
	
	private void saveSimulationState(int t, int[] info) {
		if(living.size() > 0)
		{
			double avgAge = 0;
			double avgMatureEnergy = 0;
			double[] avgParams = new double[2];
			int m = 0;
			int f = 0;
			//fractional energy usaged as juveniles are growing...
			double juvenileTdieUpkeep = 0;
			double juvenileMaturation_Energy = 0;
			double juvenileMetabolic_cost = 0;
			int num_juveniles = 0;
			//mature energy usage
			double matureMetabolic_cost = 0;
			double matureRepairCost = 0;
			double matureTotalUsed = 0;
			double matureReprodCost = 0;
			double[] state = new double[222];
			for(Creature c: living)
			{
				avgAge+=c.age;
				state[(int) (22+Math.min(99,c.properties[0]))]++;
				state[(int) (122+Math.min(99,c.properties[1]/10))]++;
				if(c.age >= c.properties[0])
				{
					//mature
					avgMatureEnergy+=c.energy;
					matureMetabolic_cost+=c.metabolic_cost;
					matureRepairCost+=c.TdieUpkeepEnergy;
					matureTotalUsed+=c.total_current_maintenance;
					matureReprodCost+=c.reproduction_energyUsed;
				}
				else
				{
					//juvenile
					if(c.total_current_maintenance > 0)
					{
						juvenileTdieUpkeep+=c.TdieUpkeepEnergy/c.total_current_maintenance;
						juvenileMaturation_Energy+=c.maturation_energy/c.total_current_maintenance;
						juvenileMetabolic_cost+=c.metabolic_cost/c.total_current_maintenance;
					}
					num_juveniles++;
				}
				for(int i = 0; i < c.properties.length;i++)
					avgParams[i]+=c.properties[i];
				if(c.female)f++;
				else m++;
			}
			avgAge/=living.size();
			int num_mature = (living.size()-num_juveniles);
			if(num_mature > 0)
			{
				avgMatureEnergy/=num_mature;
				matureMetabolic_cost/=num_mature;
				matureRepairCost/=num_mature;
				matureTotalUsed/=num_mature;
				matureReprodCost/=num_mature;
			}
			if(num_juveniles > 0)
			{
				juvenileTdieUpkeep/=num_juveniles;
				juvenileMaturation_Energy/=num_juveniles;
				juvenileMetabolic_cost/=num_juveniles;
				
			}
			for(int i = 0; i < avgParams.length; i++)
				avgParams[i]/=living.size();

			state[0] = living.size();
			state[1] = m;
			state[2] = f;
			state[3] = num_juveniles;
			state[4] = num_mature;
			state[5] = info[3];
			state[6] = info[0];
			state[7] = info[1];
			state[8] = info[2];
			state[9] = s.predationModifier*Math.pow(living.size()/((double)s.populationSize),2);
			state[10] = Energy;
			state[11] = avgAge;
			state[12] = avgMatureEnergy;
			state[13] = juvenileMaturation_Energy;
			state[14] = juvenileMetabolic_cost;
			state[15] = juvenileTdieUpkeep;
			state[16] = matureMetabolic_cost;
			state[17] = matureRepairCost;
			state[18] = matureReprodCost;
			state[19] = matureTotalUsed;
			for(int i = 0; i < avgParams.length; i++)
				state[20+i]=avgParams[i];
			for(int i = 0; i < state.length ;i++)
			{
				if(!Double.isNaN(state[i]))
					savedStates[t/s.skip][i]=state[i];
				else
					System.err.println("NAN");
			}
			for(int b = 22; b < 222; b++)
			{
				state[b]/=state[0]; //normalize
			}
			
		}
	}
	
	private void initializeSimulation()
	{
		for(int i = 0; i < s.populationSize; i++)
		{
			double[] params = new double[2];
			for(int j = 0; j < params.length; j++)
			{
				params[j] = s.initParamsMins[j]+Math.random()*s.initParamsRanges[j];
			}
			Creature c = new Creature(params,i%2==0,s);
			living.add(c);
		}
	}
	
	
	public int[] tick()
	{
		females.clear();
		males.clear();
		totalSize = 0;  //reset
		int[] cases = new int[4];  //#starve, #age, #eaten, #births
		updateEnergy();
		predationProbability = s.predationModifier*Math.pow(living.size()/((double)s.populationSize),2);
		LinkedList<Creature> stillLiving = new LinkedList<Creature>();
		for(Creature c: living)
		{
			int death_case = c.deathEffects(this);
			if(death_case ==0)
			{
				stillLiving.add(c);
				totalSize+=c.fractional_size;
				if(c.female) females.put(c,true);
				else males.put(c,true);
			}
			else
			{
				cases[death_case-1]++;
			}
		}
		living = stillLiving;
		Collection<Creature> births = reproductionEffects();
		living.addAll(births);
		cases[3] = births.size();
		Collections.shuffle(living);
		return cases;
	}
	
	
	
	public LinkedList<Creature> reproductionEffects() {
		LinkedList<Creature> givingBirth = new LinkedList<Creature>();
		ArrayList<Creature> eligibleBachelors = new ArrayList<Creature>();
		for(Creature c: males.keySet())
		{
			if(c.energy> s.matingThreshold)
			{
				eligibleBachelors.add((int) (Math.random()*eligibleBachelors.size()),c);
			}
		}

		for(Creature c: females.keySet())
		{
			if(c.age >= c.properties[0] && c.father == null)
			{
				if(eligibleBachelors.size() ==0) break;
				//lets mate them if they have enough energy to mate
				if(c.energy > s.matingThreshold )
				{
					for(Creature mate: eligibleBachelors)
					{						
						if(c.energy > s.energyToMate)
						{
							double pregnancyChance = c.mattingSuccessChance();
							c.energy-=s.energyToMate;
							mate.energy-=s.energyToMate;
							c.reproduction_energyUsed += s.energyToMate;
							mate.reproduction_energyUsed+= s.energyToMate;
							if(Math.random() < pregnancyChance)
							{
								//we were successful
								c.father = mate;
								break;
							}
						}
						else
							break;
					}
				}
			}
			if(c.father!= null)
			{
				givingBirth.add(c);
			}
		}//while
		LinkedList<Creature> offspring = new LinkedList<Creature>();
		for(Creature c: givingBirth)
		{
			Creature[] kids = c.getOffSpring();
			for(Creature cc: kids)
				offspring.add(cc);
			c.father = null;
		}
		return offspring;
	}
	private void updateEnergy() {
		// TODO Auto-generated method stub
		Energy =Math.min(s.populationSize*s.adultMetabolicCost*100,Energy+s.populationSize*s.adultMetabolicCost*s.foodMultiplier);
	}


	public double getEnergyAvailable() {
		// TODO Auto-generated method stub
		return Energy/(totalSize);
	}
	
	public double getEnergyAvailableGreedy()
	{
		return Energy;
	}
}
